import React from 'react';

import {Link} from 'react-router-dom'

function UpdatePage() {
    return (
        <>
        <Link to='/updateHosp'>update hospital</Link>
        {/* <Link to='/'>update Patient</Link> */}
        </>
      )
  }

  export default  UpdatePage;